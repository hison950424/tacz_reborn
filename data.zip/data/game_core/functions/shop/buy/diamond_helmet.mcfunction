# ==========================================
# 檔案: shop/buy_diamond_helmet.mcfunction
# ==========================================
clear @s minecraft:diamond_helmet{ShopItem:"diamond_helmet"}
execute if score @s in_base_score matches 0 at @s run playsound block.note_block.bass master @s ~ ~ ~ 1 0.5
execute if score @s in_base_score matches 0 run tellraw @s {"text":"[商店警告] 必須在基地內才能購買！","color":"dark_red","bold":true}
execute if score @s in_base_score matches 0 run return 0
execute if score @s class_type matches 2 at @s run playsound entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s class_type matches 2 run tellraw @s {"text":"[商店] 權限拒絕：您的職業無法購買！","color":"red"}
execute if score @s class_type matches 2 run return 0
scoreboard players set @s shop_price 240
execute if score @s gd656killicon.score < @s shop_price at @s run playsound entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s gd656killicon.score < @s shop_price run tellraw @s ["",{"text":"[商店] 餘額不足！需要 ","color":"red"},{"score":{"name":"@s","objective":"shop_price"},"color":"yellow"},{"text":" 元。","color":"red"}]
execute if score @s gd656killicon.score < @s shop_price run return 0
give @s minecraft:diamond_helmet{Unbreakable:1b} 1
execute at @s run playsound block.anvil.use master @s ~ ~ ~ 1 1.2
gd656killicon server statistics add score @s -240
tellraw @s ["",{"text":"[商店] 成功購買 鑽石頭盔 ！剩餘餘額：","color":"green"},{"score":{"name":"@s","objective":"gd656killicon.score"},"color":"yellow"},{"text":" 元。","color":"green"}]