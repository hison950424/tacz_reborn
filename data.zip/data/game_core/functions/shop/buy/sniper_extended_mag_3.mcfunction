# ==========================================
# 檔案: shop/buy_sniper_extended_mag_3.mcfunction
# 觸發: 玩家把「假 3級狙擊擴容彈匣」拿進背包的瞬間
# ==========================================

# 0. 【核心防弊】瞬間沒收玩家剛從箱子裡拿到的「展示假物品」
clear @s tacz:attachment{ShopItem:"sniper_extended_mag_3"}

# 1. 基地檢測 (不在基地直接中斷)
execute if score @s in_base_score matches 0 at @s run playsound block.note_block.bass master @s ~ ~ ~ 1 0.5
execute if score @s in_base_score matches 0 run tellraw @s {"text":"[商店警告] 必須在基地內才能購買！","color":"dark_red","bold":true}
execute if score @s in_base_score matches 0 run return 0

# 2. 職業檢測 (全職業皆可購買配件，不需阻擋)

# 3. 動態價格設定 (支援兵價格加收 25%)
scoreboard players set @s shop_price 500
execute if score @s class_type matches 3 run scoreboard players set @s shop_price 625

# 4. 餘額檢測 (錢不夠直接中斷)
execute if score @s gd656killicon.score < @s shop_price at @s run playsound entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s gd656killicon.score < @s shop_price run tellraw @s ["",{"text":"[商店] 餘額不足！需要 ","color":"red"},{"score":{"name":"@s","objective":"shop_price"},"color":"yellow"},{"text":" 元。","color":"red"}]
execute if score @s gd656killicon.score < @s shop_price run return 0

# 5. 發放真正的配件、音效、扣款
give @s tacz:attachment{AttachmentId:"tacz:sniper_extended_mag_3"} 1
execute at @s run playsound block.anvil.use master @s ~ ~ ~ 1 1.2
execute unless score @s class_type matches 3 run gd656killicon server statistics add score @s -500
execute if score @s class_type matches 3 run gd656killicon server statistics add score @s -625
tellraw @s ["",{"text":"[商店] 成功購買 3級狙擊擴容彈匣 ！剩餘餘額：","color":"green"},{"score":{"name":"@s","objective":"gd656killicon.score"},"color":"yellow"},{"text":" 元。","color":"green"}]