#[死鬥]殺一個人20元 bug1
gd656killicon server bonus edit ASSIST expression 0.4
gd656killicon server bonus edit BRAVE_RETURN expression 20
gd656killicon server bonus edit DESPERATE_COUNTERATTACK expression 20
gd656killicon server bonus edit INTERRUPTED_STREAK expression 20
gd656killicon server bonus edit KILL expression 0.4
gd656killicon server bonus edit KILL_COMBO expression 4
gd656killicon server bonus edit KILL_EXPLOSION expression 0.4
gd656killicon server bonus edit KILL_HEADSHOT expression 0.4
gd656killicon server bonus edit POTATO_AIM expression 20
gd656killicon server bonus edit SLAY_THE_LEADER expression 40
