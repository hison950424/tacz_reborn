# ==========================================
# 檔案: lobby_tick.mcfunction
# 目的: 大廳多層級書本路由控制 (完整修復版)
# ==========================================

# --- 每 tick 環境效果 ---
function game_core:lobby/env_tick

# --- 每秒（20 tick）邏輯 ---
scoreboard players add #lobby_env_timer lobby_env_timer 1
execute if score #lobby_env_timer lobby_env_timer matches 20.. run scoreboard players set #lobby_env_timer lobby_env_timer 0
execute if score #lobby_env_timer lobby_env_timer matches 0 run function game_core:lobby/second_tick


#迷你死鬥判斷
function game_core:player/combat_tag_tick

# --- 指令書路由（大廳終端）---
function game_core:lobby/terminal_tick

# ------------------------------------------
# 路由 A: 從 [模式選擇書] 進行選擇
# ------------------------------------------
# 選擇 1: 大逃殺 -> 清除模式選擇書，發放地圖選擇書
execute as @a[scores={select_mode=1}] run scoreboard players set #global arms_sub_mode 0
execute as @a[scores={select_mode=1}] run clear @s written_book{title:"模式選擇書"}
execute as @a[scores={select_mode=1}] run clear @s written_book{title:"大逃殺參數設定"}
execute as @a[scores={select_mode=1}] run give @s written_book{title:"大逃殺地圖選擇",author:"系統",pages:['{"text":" <<< 地圖選擇 >>>\\n\\n","color":"dark_red","bold":true,"extra":[{"text":"[ ▶ 地圖一: 經典 ]\\n\\n","color":"dark_green","clickEvent":{"action":"run_command","value":"/trigger br_map_pick set 1"}},{"text":"[ ▶ 地圖二: 腐蝕之地 ]\\n\\n","color":"dark_green","clickEvent":{"action":"run_command","value":"/trigger br_map_pick set 2"}},{"text":"[ ▶ 地圖三: 櫻峰之城 ]\\n\\n","color":"dark_green","clickEvent":{"action":"run_command","value":"/trigger br_map_pick set 3"}},{"text":"[ ▶ 地圖四: 山吹城 ]\\n\\n","color":"dark_green","clickEvent":{"action":"run_command","value":"/trigger br_map_pick set 4"}},{"text":"[ ▶ 地圖五 ]\\n","color":"dark_green","clickEvent":{"action":"run_command","value":"/trigger br_map_pick set 5"}},{"text":"   普羅米修斯禁區\\n\\n","color":"gray"},{"text":"[ ◄ 上一頁 ]","color":"gray","clickEvent":{"action":"run_command","value":"/trigger select_mode set 9"}}]}']} 1

# 選擇 2: 軍備競賽 -> 給予【軍備競賽模式選擇書】
execute as @a[scores={select_mode=2}] run clear @s written_book{title:"模式選擇書"}
execute as @a[scores={select_mode=2}] run give @s written_book{title:"軍備競賽模式選擇書",author:"系統",pages:['{"text":" ==== 軍備競賽 ====\\n\\n","color":"gold","bold":true,"extra":[{"text":"[▶ 佔點模式]\\n\\n","color":"dark_aqua","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 3"}},{"text":"[▶ 團隊死鬥模式]\\n\\n\\n","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 4"}},{"text":"[ ◄ 上一頁 ]\\n","color":"gray","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 9"}}]}']} 1
execute as @a[scores={select_mode=2}] run tellraw @s {"text":"[系統] 已開啟軍備競賽選單。","color":"yellow"}

# ------------------------------------------
# 從【軍備競賽模式選擇書】返回【模式選擇書】
# ------------------------------------------
execute as @a[scores={select_mode=9}] run clear @s written_book{title:"軍備競賽模式選擇書"}
execute as @a[scores={select_mode=9}] run clear @s written_book{title:"大逃殺地圖選擇"}
execute as @a[scores={select_mode=9}] run clear @s written_book{title:"大逃殺參數設定"}
execute as @a[scores={select_mode=9}] run scoreboard players set #global br_fast_mode 0
execute as @a[scores={select_mode=9}] run clear @s written_book{title:"模式選擇書"}
execute as @a[scores={select_mode=9}] run clear @s written_book{title:"模式與隊伍"}
execute as @a[scores={select_mode=9}] run give @s written_book{title:"模式選擇書",author:"系統",pages:['{"text":" ==== 模式選擇 ====\\n\\n","color":"dark_red","bold":true,"extra":[{"text":"[▶ 大逃殺模式]\\n\\n","color":"dark_gray","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 1"}},{"text":"[▶ 軍備競賽模式]\\n\\n","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 2"}},{"text":"[ ◄ 上一頁 ]\\n","color":"gray","bold":true,"clickEvent":{"action":"run_command","value":"/trigger lobby_terminal set 9"}}]}']} 1

# ------------------------------------------
# 路由 B: 軍備競賽 -> 佔點模式設定 (select_mode = 3)
# ------------------------------------------
execute as @a[scores={select_mode=3}] run clear @s written_book{title:"軍備競賽模式選擇書"}
execute as @a[scores={select_mode=3}] run scoreboard players set #global arms_sub_mode 2

# 避免重複發放，先清除手上的設定書
execute as @a[scores={select_mode=3}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=3}] run clear @s written_book{title:"團隊死鬥設定"}

# 發放「代理設定書」，提供返回與重新喚出 UI 的功能
execute as @a[scores={select_mode=3}] run give @s written_book{title:"佔點模式設定",author:"系統",pages:['{"text":" == 佔點參數設定 ==\\n\\n","color":"gold","bold":true,"extra":[{"text":"請在「聊天欄」中進行連點設定。\\n若聊天欄被洗掉，可點擊下方按鈕重新喚出介面。\\n\\n\\n","color":"dark_gray"},{"text":"[ 💬 重新喚出設定介面 ]\\n\\n\\n","color":"dark_purple","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 3"}},{"text":"[▶ 確認並進入職業選擇 ]\\n\\n","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 6"}},{"text":"[ ◄ 上一頁 ]\\n","color":"gray","bold":true,"bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 7"}}]}']} 1

execute as @a[scores={select_mode=3}] run tellraw @s {"text":"[系統] 已選擇佔點模式，請在聊天欄設定參數。","color":"yellow"}
# 職業選擇後呼叫系統資料夾中的渲染 UI 所以在下面
# execute as @a[scores={select_mode=3}] run function game_core:gamemode/dom/config_render

# ------------------------------------------
# 選擇 4: 團隊死鬥模式 -> 給予【團隊死鬥設定】
# ------------------------------------------
execute as @a[scores={select_mode=4}] run clear @s written_book{title:"軍備競賽模式選擇書"}
execute as @a[scores={select_mode=4}] run scoreboard players set #global arms_sub_mode 1

# 避免重複發放，先清除手上的設定書
execute as @a[scores={select_mode=4}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=4}] run clear @s written_book{title:"團隊死鬥設定"}

# 發放「代理設定書」，提供返回與重新喚出 UI 的功能
execute as @a[scores={select_mode=4}] run give @s written_book{title:"團隊死鬥設定",author:"系統",pages:['{"text":" == TDM 參數設定 ==\\n\\n","color":"dark_red","bold":true,"extra":[{"text":"請在「聊天欄」中進行連點設定。\\n若聊天欄被洗掉，可點擊下方按鈕重新喚出介面。\\n\\n\\n","color":"dark_gray"},{"text":"[ 💬 重新喚出設定介面 ]\\n\\n\\n","color":"dark_purple","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 4"}},{"text":"[▶ 確認並進入職業選擇 ]\\n\\n","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 6"}},{"text":"[ ◄ 上一頁 ]\\n","color":"gray","bold":true,"bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 7"}}]}']} 1

execute as @a[scores={select_mode=4}] run tellraw @s {"text":"[系統] 已選擇團隊死鬥，請在聊天欄設定參數。","color":"yellow"}
# 職業選擇後呼叫系統資料夾中的渲染 UI 所以在下面
# execute as @a[scores={select_mode=4}] run function game_core:gamemode/tdm/config_render

# ------------------------------------------
# 從【參數設定代理書】返回【軍備競賽模式選擇書】 (select_mode = 7)
# ------------------------------------------
execute as @a[scores={select_mode=7}] run clear @s written_book{title:"團隊死鬥設定"}
execute as @a[scores={select_mode=7}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=7}] run give @s written_book{title:"軍備競賽模式選擇書",author:"系統",pages:['{"text":" ==== 軍備競賽 ====\\n\\n","color":"gold","bold":true,"extra":[{"text":"[▶ 佔點模式]\\n\\n","color":"dark_aqua","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 3"}},{"text":"[▶ 團隊死鬥模式]\\n\\n\\n","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 4"}},{"text":"[ ◄ 上一頁 ]\\n","color":"gray","bold":true,"bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 9"}}]}']} 1

# 開啟觸發權限 (每 Tick 執行)
scoreboard players enable @a btn_score_up
scoreboard players enable @a btn_score_dn
scoreboard players enable @a btn_time_up
scoreboard players enable @a btn_time_dn

# --- [A] 分數增加與重置 ---
execute as @a[scores={btn_score_up=1..9998}] run playsound ui.button.click master @s ~ ~ ~ 1 1
# 根據子模式修改對應變數
execute as @a[scores={btn_score_up=1..9998}] if score #global arms_sub_mode matches 1 run scoreboard players operation #target_score tdm_config += @s btn_score_up
execute as @a[scores={btn_score_up=1..9998}] if score #global arms_sub_mode matches 2 run scoreboard players operation #target_score dom_config += @s btn_score_up

# 重置邏輯 (9999)
execute as @a[scores={btn_score_up=9999}] run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
execute as @a[scores={btn_score_up=9999}] if score #global arms_sub_mode matches 1 run scoreboard players set #target_score tdm_config 100 
execute as @a[scores={btn_score_up=9999}] if score #global arms_sub_mode matches 2 run scoreboard players set #target_score dom_config 100

# --- [B] 分數減少與防呆 ---
# TDM 減少與防呆 (下限 10)
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 1 if score #target_score tdm_config matches 11.. run playsound ui.button.click master @s ~ ~ ~ 1 1
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 1 if score #target_score tdm_config matches 11.. run scoreboard players operation #target_score tdm_config -= @s btn_score_dn 
execute if score #global arms_sub_mode matches 1 if score #target_score tdm_config matches ..9 run scoreboard players set #target_score tdm_config 10 
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 1 if score #target_score tdm_config matches ..10 run playsound block.note_block.bass master @s ~ ~ ~ 1 0.5

# DOM 減少與防呆 (下限 100)
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 2 if score #target_score dom_config matches 101.. run playsound ui.button.click master @s ~ ~ ~ 1 1
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 2 if score #target_score dom_config matches 101.. run scoreboard players operation #target_score dom_config -= @s btn_score_dn
execute if score #global arms_sub_mode matches 2 if score #target_score dom_config matches ..99 run scoreboard players set #target_score dom_config 100
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 2 if score #target_score dom_config matches ..100 run playsound block.note_block.bass master @s ~ ~ ~ 1 0.5

# --- [C] 時間增加與重置 (TDM only) ---
execute as @a[scores={btn_time_up=1..9998}] if score #global arms_sub_mode matches 1 run playsound ui.button.click master @s ~ ~ ~ 1 1
execute as @a[scores={btn_time_up=1..9998}] if score #global arms_sub_mode matches 1 run scoreboard players operation #time_limit_sec tdm_config += @s btn_time_up

execute as @a[scores={btn_time_up=9999}] if score #global arms_sub_mode matches 1 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
execute as @a[scores={btn_time_up=9999}] if score #global arms_sub_mode matches 1 run scoreboard players set #time_limit_sec tdm_config 600

# --- [D] 時間減少與防呆 (TDM only, 下限 60 秒) ---
execute as @a[scores={btn_time_dn=1..}] if score #global arms_sub_mode matches 1 if score #time_limit_sec tdm_config matches 61.. run playsound ui.button.click master @s ~ ~ ~ 1 1
execute as @a[scores={btn_time_dn=1..}] if score #global arms_sub_mode matches 1 if score #time_limit_sec tdm_config matches 61.. run scoreboard players operation #time_limit_sec tdm_config -= @s btn_time_dn
execute if score #global arms_sub_mode matches 1 if score #time_limit_sec tdm_config matches ..59 run scoreboard players set #time_limit_sec tdm_config 60
execute as @a[scores={btn_time_dn=1..}] if score #global arms_sub_mode matches 1 if score #time_limit_sec tdm_config matches ..60 run playsound block.note_block.bass master @s ~ ~ ~ 1 0.5


# ==========================================
# 核心：判定變動並「原地刷新介面」
# ==========================================
# 只要有任何按鈕被按下，依照目前的子模式重新發送 UI
# 1. 初始點擊書本時的呼叫路徑
execute as @a[scores={select_mode=3}] run function game_core:gamemode/dom/config_render
execute as @a[scores={select_mode=4}] run function game_core:gamemode/tdm/config_render

# 2. 觸發按鈕連點後的「原地刷新」呼叫路徑
execute as @a[scores={btn_score_up=1..}] if score #global arms_sub_mode matches 1 run function game_core:gamemode/tdm/config_render
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 1 run function game_core:gamemode/tdm/config_render
execute as @a[scores={btn_time_up=1..}] if score #global arms_sub_mode matches 1 run function game_core:gamemode/tdm/config_render
execute as @a[scores={btn_time_dn=1..}] if score #global arms_sub_mode matches 1 run function game_core:gamemode/tdm/config_render

execute as @a[scores={btn_score_up=1..}] if score #global arms_sub_mode matches 2 run function game_core:gamemode/dom/config_render
execute as @a[scores={btn_score_dn=1..}] if score #global arms_sub_mode matches 2 run function game_core:gamemode/dom/config_render
execute as @a[scores={btn_time_up=1..}] if score #global arms_sub_mode matches 2 run function game_core:gamemode/dom/config_render
execute as @a[scores={btn_time_dn=1..}] if score #global arms_sub_mode matches 2 run function game_core:gamemode/dom/config_render

# 清空所有觸發器狀態 (取代原本的 reset，避免權限遺失)
scoreboard players set @a btn_score_up 0
scoreboard players set @a btn_score_dn 0
scoreboard players set @a btn_time_up 0
scoreboard players set @a btn_time_dn 0


# ------------------------------------------
# 路由 C: 確認參數並發放【職業選擇書】與【啟動書】
# ------------------------------------------
execute if score #global arms_sub_mode matches 1 as @a[scores={select_mode=6}] run tellraw @a {"text":"[系統] 管理員已設定完畢！團隊死鬥即將開始，請選擇你的職業。","color":"gold","bold":true}
execute if score #global arms_sub_mode matches 2 as @a[scores={select_mode=6}] run tellraw @a {"text":"[系統] 管理員已設定完畢！佔點模式即將開始，請選擇你的職業。","color":"gold","bold":true}

# 透過發送 40 個換行符，推擠並隱藏先前的設定 UI
execute as @a[scores={select_mode=6}] run tellraw @s {"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"}

# 清除可能殘留的設定代理書
execute as @a[scores={select_mode=6}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=6}] run clear @s written_book{title:"團隊死鬥設定"}
execute as @a[scores={select_mode=6}] run clear @s written_book{title:"職業選擇"}
execute as @a[scores={select_mode=6}] run clear @s written_book{title:"系統啟動確認"}

# 發放職業書給所有人，並清空管理員手上的設定書
execute as @a[scores={select_mode=6}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=6}] at @s run give @a written_book{title:"職業選擇",author:"系統",pages:['{"text":" ==== 選擇職業 ====\\n\\n","color":"dark_aqua","bold":true,"extra":[{"text":"[ 自由人 (80 HP) ]\\n\\n","color":"gray","bold":true,"bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_class set 1"}},{"text":"[ 突擊兵 (100 HP) ]\\n\\n","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_class set 2"}},{"text":"[ 支援兵 (100 HP) ]\\n\\n","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_class set 3"}},{"text":"[ 哨兵 (100 HP) ]\\n","color":"blue","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_class set 4"}}]}']} 1

# 給予管理員「強制啟動」的權限書
execute as @a[scores={select_mode=6},tag=admin] run give @s written_book{title:"系統啟動確認",author:"系統",pages:['{"text":" ==== 啟動確認 ====\\n\\n請等待所有玩家選擇完畢後，點擊下方按鈕正式開始遊戲。\\n\\n\\n\\n","color":"dark_red","bold":true,"extra":[{"text":"[▶ 開始遊戲 ]\\n\\n","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 5"}},{"text":"[ 返回重選模式 ]\\n","color":"gray","bold":true,"bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 8"}}]}']} 1


# ==========================================
# 觸發器: 取消啟動與重置返回 (select_mode = 8)
# ==========================================
execute as @a[scores={select_mode=8}] run clear @s written_book{title:"系統啟動確認"}
execute as @a[scores={select_mode=8}] run clear @a written_book{title:"職業選擇"}

# 清除可能殘留的設定代理書
execute as @a[scores={select_mode=8}] run clear @s written_book{title:"佔點模式設定"}
execute as @a[scores={select_mode=8}] run clear @s written_book{title:"團隊死鬥設定"}

execute as @a[scores={select_mode=8}] run scoreboard players set @a class_type 0
execute as @a[scores={select_mode=8}] run tellraw @a {"text":"[系統] 管理員已取消遊戲啟動，請等待重新設定。","color":"yellow"}

# 給予初始的「模式選擇書」重新開始
execute as @a[scores={select_mode=8}] run give @s written_book{title:"模式選擇書",author:"系統",pages:['{"text":" ==== 模式選擇 ====\\n\\n","color":"dark_red","bold":true,"extra":[{"text":"[▶ 大逃殺模式]\\n\\n","color":"dark_gray","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 1"}},{"text":"[▶ 軍備競賽模式]\\n","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger select_mode set 2"}}]}']} 1


# ------------------------------------------
# 路由 D: 處理玩家點擊【職業選擇書】 (原封不動保留)
# ------------------------------------------
# ==== 自由人 (1) ====
execute as @a[scores={select_class=1}] run scoreboard players set @s class_type 1
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":"\n\n\n\n\n\n\n\n\n\n"}]
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":"[系統] ","color":"gold"},{"text":"已選擇職業: ","color":"white"},{"text":"自由人！","color":"aqua"}]
execute as @a[scores={select_class=1}] run tellraw @s {"text":""}
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":" + ","color":"green"},{"text":"Buff:「武器大師」","color":"green"}]
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"可購買和使用所有武器、配件與道具。","color":"white"}]
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":" - ","color":"red"},{"text":"Debuff:「孤狼代價」","color":"red"}]
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"最大生命值上限為 80 HP (-20%)。","color":"white"}]
execute as @a[scores={select_class=1}] run tellraw @s {"text":""}
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"可購買裝備: ","color":"yellow"},{"text":"無任何限制。","color":"white"}]
execute as @a[scores={select_class=1}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"關於投擲物: ","color":"yellow"},{"text":"你是唯一需要自己花錢購買的職業。","color":"white"}]

# ==== 突擊兵 (2) ====
execute as @a[scores={select_class=2}] run scoreboard players set @s class_type 2
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":"\n\n\n\n\n\n\n\n\n\n"}]
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":"[系統] ","color":"gold"},{"text":"已選擇職業: ","color":"white"},{"text":"突擊兵！","color":"aqua"}]
execute as @a[scores={select_class=2}] run tellraw @s {"text":""}
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":" + ","color":"green"},{"text":"Buff:「輕裝上陣」","color":"green"}]
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"移動速度 +40%。","color":"white"}]
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":" - ","color":"red"},{"text":"Debuff:「輕裝協議」","color":"red"}]
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"無法購買或穿戴鐵等級以上(不含)的防具、無法購買高倍鏡。","color":"white"}]
execute as @a[scores={select_class=2}] run tellraw @s {"text":""}
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"可購買主武器: ","color":"yellow"},{"text":"散彈槍, 衝鋒槍，步槍","color":"white"}]
execute as @a[scores={select_class=2}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"固有投擲物: ","color":"yellow"},{"text":"擊殺敵人後自動補充 ","color":"white"},{"text":"閃光彈,破片手榴彈","color":"aqua"}]

# ==== 支援兵 (3) ====
execute as @a[scores={select_class=3}] run scoreboard players set @s class_type 3
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":"\n\n\n\n\n\n\n\n\n\n"}]
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":"[系統] ","color":"gold"},{"text":"已選擇職業: ","color":"white"},{"text":"支援兵！","color":"aqua"}]
execute as @a[scores={select_class=3}] run tellraw @s {"text":""}
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":" + ","color":"green"},{"text":"Buff:「戰術補給」","color":"green"}]
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"補包增強為強化補包。","color":"white"}]
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":" - ","color":"red"},{"text":"Debuff:「後勤負擔」","color":"red"}]
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"所有物品的購買價格 +25%。","color":"white"}]
execute as @a[scores={select_class=3}] run tellraw @s {"text":""}
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"可購買主武器: ","color":"yellow"},{"text":"霰彈槍, 步槍，機槍","color":"white"}]
execute as @a[scores={select_class=3}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"固有投擲物: ","color":"yellow"},{"text":"所有投擲物。","color":"white"}]

# ==== 哨兵 (4) ====
execute as @a[scores={select_class=4}] run scoreboard players set @s class_type 4
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":"\n\n\n\n\n\n\n\n\n\n"}]
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":"[系統] ","color":"gold"},{"text":"已選擇職業: ","color":"white"},{"text":"哨兵！","color":"aqua"}]
execute as @a[scores={select_class=4}] run tellraw @s {"text":""}
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":" + ","color":"green"},{"text":"Buff:「陣地固守」","color":"green"}]
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"蹲下後，獲得 20% 傷害減免。","color":"white"}]
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":" - ","color":"red"},{"text":"Debuff:「重裝步兵」","color":"red"}]
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":"   效果: ","color":"gray"},{"text":"移動速度 -40%。","color":"white"}]
execute as @a[scores={select_class=4}] run tellraw @s {"text":""}
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"可購買主武器: ","color":"yellow"},{"text":"狙擊槍, 衝鋒槍，機槍","color":"white"}]
execute as @a[scores={select_class=4}] run tellraw @s ["",{"text":" ▸ ","color":"gold"},{"text":"固有投擲物: ","color":"yellow"},{"text":"擊殺敵人後自動補充 ","color":"white"},{"text":"煙霧彈,瞬爆手榴彈","color":"aqua"}]

# 職業選擇後呼叫系統資料夾中的渲染 UI
execute as @a[scores={select_mode=3}] run function game_core:gamemode/dom/config_render
# 職業選擇後呼叫系統資料夾中的渲染 UI
execute as @a[scores={select_mode=4}] run function game_core:gamemode/tdm/config_render


# ------------------------------------------
# 路由 E: 管理員按下【強制開始遊戲】(軍備競賽)
# ------------------------------------------
execute as @a[scores={select_mode=5},tag=admin] run clear @s written_book{title:"系統啟動確認"}
execute as @a[scores={select_mode=5},tag=admin] run function game_core:gamemode/arms_race/start

# ------------------------------------------
# 路由 BR: 地圖選擇 (br_map_pick trigger)
# 鐵律：必須在 E2 (開始大逃殺) 之前執行！
# 原因：同一 Tick 內若玩家選圖＋管理員開局，要確保 #global br_map 已更新
#       再由 start_battle_royale 讀取，否則總是使用上一局或 init 的預設值。
# ------------------------------------------
scoreboard players enable @a br_map_pick
execute as @a[scores={br_map_pick=1}] run scoreboard players set #global br_map 1
execute as @a[scores={br_map_pick=1}] run tellraw @s {"text":"[系統] 已選擇地圖一：經典","color":"green"}
execute as @a[scores={br_map_pick=2}] run scoreboard players set #global br_map 2
execute as @a[scores={br_map_pick=2}] run tellraw @s {"text":"[系統] 已選擇地圖二：腐蝕之地","color":"green"}
execute as @a[scores={br_map_pick=3}] run scoreboard players set #global br_map 3
execute as @a[scores={br_map_pick=3}] run tellraw @s {"text":"[系統] 已選擇地圖三：櫻峰之城","color":"green"}
execute as @a[scores={br_map_pick=4}] run scoreboard players set #global br_map 4
execute as @a[scores={br_map_pick=4}] run tellraw @s {"text":"[系統] 已選擇地圖四：山吹城","color":"green"}
execute as @a[scores={br_map_pick=5}] run scoreboard players set #global br_map 5
execute as @a[scores={br_map_pick=5}] run tellraw @s {"text":"[系統] 已選擇地圖五：普羅米修斯禁區","color":"green"}
execute as @a[scores={br_map_pick=1..}] at @s run playsound ui.button.click master @s ~ ~ ~ 1 1
# 選圖完成後，對管理員發放 BR 參數設定書
execute as @a[scores={br_map_pick=1..},tag=admin] run function game_core:lobby/give_br_params_book
scoreboard players set @a[scores={br_map_pick=1..}] br_map_pick 0

# ------------------------------------------
# 路由 BR-TIME: 遊戲時間選擇 (br_time_pick trigger)
# ------------------------------------------
scoreboard players enable @a br_time_pick
execute as @a[scores={br_time_pick=1}] run scoreboard players set #global br_time 1
execute as @a[scores={br_time_pick=1}] run time set noon
execute as @a[scores={br_time_pick=1}] run tellraw @s {"text":"[系統] 遊戲時間已設定：☀ 白天","color":"gold"}
execute as @a[scores={br_time_pick=2}] run scoreboard players set #global br_time 2
execute as @a[scores={br_time_pick=2}] run time set 12400
execute as @a[scores={br_time_pick=2}] run tellraw @s {"text":"[系統] 遊戲時間已設定：🌅 黃昏","color":"dark_red"}
execute as @a[scores={br_time_pick=3}] run scoreboard players set #global br_time 3
execute as @a[scores={br_time_pick=3}] run time set midnight
execute as @a[scores={br_time_pick=3}] run tellraw @s {"text":"[系統] 遊戲時間已設定：🌙 夜晚","color":"dark_purple"}
execute as @a[scores={br_time_pick=1..}] at @s run playsound ui.button.click master @s ~ ~ ~ 1 1
scoreboard players set @a[scores={br_time_pick=1..}] br_time_pick 0

# ------------------------------------------
# 路由 BR-WEATHER: 天氣選擇 (br_weather_pick trigger)
# ------------------------------------------
scoreboard players enable @a br_weather_pick
execute as @a[scores={br_weather_pick=1}] run scoreboard players set #global br_weather 1
execute as @a[scores={br_weather_pick=1}] run weather clear 999999
execute as @a[scores={br_weather_pick=1}] run tellraw @s {"text":"[系統] 天氣已設定：☀ 晴天","color":"yellow"}
execute as @a[scores={br_weather_pick=2}] run scoreboard players set #global br_weather 2
execute as @a[scores={br_weather_pick=2}] run weather rain 999999
execute as @a[scores={br_weather_pick=2}] run tellraw @s {"text":"[系統] 天氣已設定：🌧 雨天","color":"aqua"}
execute as @a[scores={br_weather_pick=3}] run scoreboard players set #global br_weather 3
execute as @a[scores={br_weather_pick=3}] run weather thunder 999999
execute as @a[scores={br_weather_pick=3}] run tellraw @s {"text":"[系統] 天氣已設定：⛈ 雷雨","color":"dark_aqua"}
execute as @a[scores={br_weather_pick=1..}] at @s run playsound ui.button.click master @s ~ ~ ~ 1 1
scoreboard players set @a[scores={br_weather_pick=1..}] br_weather_pick 0


# ------------------------------------------
# 路由 BR-FAST: 快速模式切換 (br_fast_mode_pick trigger)
# set 1 = 開啟，set 2 = 關閉
# ------------------------------------------
scoreboard players enable @a br_fast_mode_pick
execute as @a[scores={br_fast_mode_pick=1}] run scoreboard players set #global br_fast_mode 1
execute as @a[scores={br_fast_mode_pick=1}] run tellraw @s {"text":"[系統] ⚡ 快速模式：已開啟","color":"red","bold":true}
execute as @a[scores={br_fast_mode_pick=2}] run scoreboard players set #global br_fast_mode 0
execute as @a[scores={br_fast_mode_pick=2}] run tellraw @s {"text":"[系統] ⚡ 快速模式：已關閉","color":"gray"}
execute as @a[scores={br_fast_mode_pick=1..}] at @s run playsound ui.button.click master @s ~ ~ ~ 1 1
scoreboard players set @a[scores={br_fast_mode_pick=1..}] br_fast_mode_pick 0

# ------------------------------------------
# 路由 BR-INFO: 查看目前 BR 遊戲配置 (select_mode = 13)
# ------------------------------------------
execute as @a[scores={select_mode=13}] run tellraw @s ["",{"text":"━━━ BR 目前配置 ━━━","color":"gold","bold":true}]
execute as @a[scores={select_mode=13}] if score #global br_map matches 1 run tellraw @s {"text":"  🗺 地圖：地圖一 - 經典","color":"dark_green"}
execute as @a[scores={select_mode=13}] if score #global br_map matches 2 run tellraw @s {"text":"  🗺 地圖：地圖二 - 腐蝕之地","color":"dark_green"}
execute as @a[scores={select_mode=13}] if score #global br_map matches 3 run tellraw @s {"text":"  🗺 地圖：地圖三 - 櫻峰之城","color":"dark_green"}
execute as @a[scores={select_mode=13}] if score #global br_map matches 4 run tellraw @s {"text":"  🗺 地圖：地圖四 - 山吹城","color":"dark_green"}
execute as @a[scores={select_mode=13}] if score #global br_map matches 5 run tellraw @s {"text":"  🗺 地圖：地圖五 - 普羅米修斯禁區","color":"dark_green"}
execute as @a[scores={select_mode=13}] if score #global br_time matches 1 run tellraw @s {"text":"  ☀ 時間：白天","color":"yellow"}
execute as @a[scores={select_mode=13}] if score #global br_time matches 2 run tellraw @s {"text":"  🌅 時間：黃昏","color":"dark_red"}
execute as @a[scores={select_mode=13}] if score #global br_time matches 3 run tellraw @s {"text":"  🌙 時間：夜晚","color":"dark_purple"}
execute as @a[scores={select_mode=13}] if score #global br_weather matches 1 run tellraw @s {"text":"  ☀ 天氣：晴天","color":"yellow"}
execute as @a[scores={select_mode=13}] if score #global br_weather matches 2 run tellraw @s {"text":"  🌧 天氣：雨天","color":"aqua"}
execute as @a[scores={select_mode=13}] if score #global br_weather matches 3 run tellraw @s {"text":"  ⛈ 天氣：雷雨","color":"dark_aqua"}
execute as @a[scores={select_mode=13}] if score #global br_fast_mode matches 1 run tellraw @s {"text":"  ⚡ 快速模式：開啟","color":"red","bold":true}
execute as @a[scores={select_mode=13}] if score #global br_fast_mode matches 0 run tellraw @s {"text":"  ⚡ 快速模式：關閉","color":"gray"}

# ------------------------------------------
# 路由 E2: 管理員按下【開始大逃殺】(select_mode = 10)
# ------------------------------------------
execute as @a[scores={select_mode=10},tag=admin] run clear @s written_book{title:"大逃殺地圖選擇"}
execute as @a[scores={select_mode=10},tag=admin] run clear @s written_book{title:"大逃殺參數設定"}
execute as @a[scores={select_mode=10},tag=admin] run function game_core:gamemode/br/start

# ------------------------------------------
# 路由 F: 處理玩家加入隊伍 (join_team)
# ------------------------------------------
# 先清除舊的 solo tag，避免重複選擇時標記殘留
execute as @a[scores={join_team=1}] run tag @s remove solo
execute as @a[scores={join_team=1}] run team join red @s
execute as @a[scores={join_team=1}] run tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" 加入了 ","color":"yellow"},{"text":"紅隊！","color":"red"}]

# 先清除舊的 solo tag，避免重複選擇時標記殘留
execute as @a[scores={join_team=2}] run tag @s remove solo
execute as @a[scores={join_team=2}] run team join blue @s
execute as @a[scores={join_team=2}] run tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" 加入了 ","color":"yellow"},{"text":"藍隊！","color":"blue"}]

# 先清除舊的 solo tag，避免重複選擇時標記殘留
execute as @a[scores={join_team=3}] run tag @s remove solo
execute as @a[scores={join_team=3}] run team join white @s
execute as @a[scores={join_team=3}] run tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" 加入了 ","color":"yellow"},{"text":"白隊！","color":"white"}]

# 先清除舊的 solo tag，避免重複選擇時標記殘留
execute as @a[scores={join_team=4}] run tag @s remove solo
execute as @a[scores={join_team=4}] run team join green @s
execute as @a[scores={join_team=4}] run tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" 加入了 ","color":"yellow"},{"text":"綠隊！","color":"green"}]

#加入孤狼
# 先清除舊的 solo tag，避免重複選擇時標記殘留
execute as @a[scores={join_team=5}] run tag @s remove solo

# ── slot 1 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo1,gamemode=!spectator] run team join solo1 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo1] run tag @s add solo

# ── slot 2 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo2,gamemode=!spectator] run team join solo2 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo2] run tag @s add solo

# ── slot 3 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo3,gamemode=!spectator] run team join solo3 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo3] run tag @s add solo

# ── slot 4 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo4,gamemode=!spectator] run team join solo4 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo4] run tag @s add solo

# ── slot 5 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo5,gamemode=!spectator] run team join solo5 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo5] run tag @s add solo

# ── slot 6 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo6,gamemode=!spectator] run team join solo6 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo6] run tag @s add solo

# ── slot 7 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo7,gamemode=!spectator] run team join solo7 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo7] run tag @s add solo

# ── slot 8 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo8,gamemode=!spectator] run team join solo8 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo8] run tag @s add solo

# ── slot 9 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo9,gamemode=!spectator] run team join solo9 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo9] run tag @s add solo

# ── slot 10 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo10,gamemode=!spectator] run team join solo10 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo10] run tag @s add solo

# ── slot 11 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo11,gamemode=!spectator] run team join solo11 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo11] run tag @s add solo

# ── slot 12 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo12,gamemode=!spectator] run team join solo12 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo12] run tag @s add solo

# ── slot 13 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo13,gamemode=!spectator] run team join solo13 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo13] run tag @s add solo

# ── slot 14 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo14,gamemode=!spectator] run team join solo14 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo14] run tag @s add solo

# ── slot 15 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo15,gamemode=!spectator] run team join solo15 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo15] run tag @s add solo

# ── slot 16 ──
execute as @a[scores={join_team=5},tag=!solo] unless entity @a[team=solo16,gamemode=!spectator] run team join solo16 @s
execute as @a[scores={join_team=5}] if entity @s[team=solo16] run tag @s add solo



# ── 溢出：16 格全滿，循環分配至四色隊（不給 tag=solo）──
execute as @a[scores={join_team=5},tag=!solo] run title @s actionbar {"text":"孤狼名額已滿，已自動分配至組隊模式","color":"yellow"}
execute as @a[scores={join_team=5},tag=!solo] run function game_core:team/random_2

execute as @a[scores={join_team=5},tag=solo] run tellraw @a ["",{"selector":"@s","color":"gold"},{"text":" 加入了 ","color":"yellow"},{"text":"孤狼！","color":"gray"}]

#防止solo玩家退出遊戲再進遊戲後與其他玩家在同一個solo隊伍
scoreboard players set #solo_team dummy 0
scoreboard players set #solo_team_count dummy 0
execute as @a[team=solo1,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo2,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo3,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo4,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo5,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo6,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo7,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo8,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo9,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo10,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo11,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo12,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo13,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo14,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo15,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[team=solo16,limit=1] run scoreboard players add #solo_team dummy 1
execute as @a[tag=solo] run scoreboard players add #solo_team_count dummy 1
execute unless score #solo_team dummy = #solo_team_count dummy as @a[tag=solo] run team leave @s
execute unless score #solo_team dummy = #solo_team_count dummy as @a[tag=solo] run tag @s remove solo



# ------------------------------------------
# 路由 G: 管理員隊伍控制 (admin_team_ctrl) (原封不動保留)
# ------------------------------------------
execute as @a[scores={admin_team_ctrl=1}] run tellraw @a {"text":"[系統] 管理員已將所有人隨機分為 兩隊！","color":"yellow"}
execute as @a[scores={admin_team_ctrl=1}] run tag @a remove solo
execute as @a[scores={admin_team_ctrl=1}] run execute store result score #team_turn temp_score run random value 1..2
execute as @a[scores={admin_team_ctrl=1}] run execute as @a[sort=random] run function game_core:team/random_2
execute as @a[scores={admin_team_ctrl=1}] run execute as @a[sort=random] run function game_core:lobby/rp_leaderboard_update
execute as @a[scores={admin_team_ctrl=1}] run execute as @a[sort=random] run function game_core:lobby/event_leaderboard_update


execute as @a[scores={admin_team_ctrl=2}] run tellraw @a {"text":"[系統] 管理員已將所有人隨機分為 三隊！","color":"yellow"}
execute as @a[scores={admin_team_ctrl=2}] run tag @a remove solo
execute as @a[scores={admin_team_ctrl=2}] run execute store result score #team_turn temp_score run random value 1..3
execute as @a[scores={admin_team_ctrl=2}] run execute as @a[sort=random] run function game_core:team/random_3
execute as @a[scores={admin_team_ctrl=2}] run execute as @a[sort=random] run function game_core:lobby/rp_leaderboard_update
execute as @a[scores={admin_team_ctrl=2}] run execute as @a[sort=random] run function game_core:lobby/event_leaderboard_update


execute as @a[scores={admin_team_ctrl=3}] run tellraw @a {"text":"[系統] 管理員已將所有人隨機分為 四隊！","color":"yellow"}
execute as @a[scores={admin_team_ctrl=3}] run tag @a remove solo
execute as @a[scores={admin_team_ctrl=3}] run execute store result score #team_turn temp_score run random value 1..4
execute as @a[scores={admin_team_ctrl=3}] run execute as @a[sort=random] run function game_core:team/random_4
execute as @a[scores={admin_team_ctrl=3}] run execute as @a[sort=random] run function game_core:lobby/rp_leaderboard_update
execute as @a[scores={admin_team_ctrl=3}] run execute as @a[sort=random] run function game_core:lobby/event_leaderboard_update

execute as @a[scores={admin_team_ctrl=4}] run function game_core:lobby/clear_all_lobby_books
execute as @a[scores={admin_team_ctrl=4}] run function game_core:lobby/give_all_books
execute as @a[scores={admin_team_ctrl=4}] run tellraw @a {"text":"[系統] 管理員已收回隊伍選擇書。","color":"yellow"}

# 全員加入孤狼（清空所有隊伍，依序分配至孤狼槽位）
execute as @a[scores={admin_team_ctrl=5}] run tag @a remove solo
execute as @a[scores={admin_team_ctrl=5}] run team leave @a
# execute as @a[scores={admin_team_ctrl=5}] run execute as @a run function game_core:gamemode/br/deploy/assign_solo
execute as @a[scores={admin_team_ctrl=5}] run tellraw @a {"text":"[系統] 管理員已將所有玩家設為孤狼！","color":"yellow"}

# ------------------------------------------
# 路由 H: 管理員比賽模式控制 (admin_event_ctrl)
# ------------------------------------------
scoreboard players enable @a[tag=admin] admin_event_ctrl

execute as @a[scores={admin_event_ctrl=1},tag=admin] run scoreboard players set #global event_mode 1
execute as @a[scores={admin_event_ctrl=1},tag=admin] run tellraw @a ["",{"text":"[系統] ","color":"gold","bold":true},{"text":"比賽模式已開啟！每場比賽的 RP 將累計至比賽積分。","color":"green"}]
execute if entity @a[scores={admin_event_ctrl=1},tag=admin] run function game_core:lobby/event_leaderboard_auto_refresh
execute as @a[scores={admin_event_ctrl=1},tag=admin] at @s run playsound entity.player.levelup master @a ~ ~ ~ 1 1.2

execute as @a[scores={admin_event_ctrl=2},tag=admin] run scoreboard players set #global event_mode 0
execute as @a[scores={admin_event_ctrl=2},tag=admin] run tellraw @a ["",{"text":"[系統] ","color":"gold","bold":true},{"text":"比賽模式已關閉。","color":"yellow"}]
execute if entity @a[scores={admin_event_ctrl=2},tag=admin] run function game_core:lobby/event_leaderboard_auto_refresh
execute as @a[scores={admin_event_ctrl=2},tag=admin] at @s run playsound block.note_block.bass master @a ~ ~ ~ 1 0.8

execute as @a[scores={admin_event_ctrl=3},tag=admin] run scoreboard players set @a event_score 0
execute as @a[scores={admin_event_ctrl=3},tag=admin] run function game_core:lobby/event_leaderboard_update
execute as @a[scores={admin_event_ctrl=3},tag=admin] run tellraw @a ["",{"text":"[系統] ","color":"gold","bold":true},{"text":"比賽積分已重置為 0。","color":"red"}]
execute as @a[scores={admin_event_ctrl=3},tag=admin] at @s run playsound block.anvil.land master @a ~ ~ ~ 1 1.2

scoreboard players set @a[scores={admin_event_ctrl=1..}] admin_event_ctrl 0

# ------------------------------------------
# 收尾防呆與音效回饋 (原封不動保留)
# ------------------------------------------
execute as @a[scores={select_mode=1..}] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
execute as @a[scores={select_class=1..}] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
scoreboard players set @a[scores={select_mode=1..}] select_mode 0
scoreboard players set @a[scores={select_class=1..}] select_class 0
scoreboard players enable @a select_mode
scoreboard players enable @a select_class

execute as @a[scores={join_team=1..}] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
execute as @a[scores={join_team=1..}] at @s run function game_core:lobby/rp_leaderboard_update
execute as @a[scores={join_team=1..}] at @s run function game_core:lobby/event_leaderboard_update
execute as @a[scores={admin_team_ctrl=1..}] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
scoreboard players set @a[scores={join_team=1..}] join_team 0
scoreboard players set @a[scores={admin_team_ctrl=1..}] admin_team_ctrl 0
scoreboard players enable @a join_team
scoreboard players enable @a admin_team_ctrl



