# ==========================================
# 檔案: give_ammo_box.mcfunction
# 目的: 發放無限彈藥箱（玩家身上已有則不重複給予）
# ==========================================

execute unless entity @s[nbt={Inventory:[{id:"tacz:ammo_box",tag:{AllTypeCreative:1b}}]}] run give @s tacz:ammo_box{AllTypeCreative:1b} 1
